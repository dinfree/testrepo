package memo;

public interface Manager {
	public void Login();
	public void newUser();
	public void Userlist();
	public void newMemo();
	public void start();
	public void DeleteMemo();
	public void Memolist();
	public void OpenMemo();
}
