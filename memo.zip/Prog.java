package memo;

public class Prog {
	public static void main(String[] args) {
        MS ms = new MS();
        ms.start();
    }
}