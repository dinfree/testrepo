package mytoss;

public class User {
	//계좌번호, 이름
	private Account account;
	private String name;
	
	//생성자
	public User() { }
	
	public User(Account account, String name) {
		this.account = account;
		this.name = name;
	}
	
	//getter, setter
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
