package mytoss;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class MyToss implements Toss {
	ArrayList<User> users = new ArrayList<>();
	User curUser = new User();
	ArrayList<Account> accounts = new ArrayList<>();
	Account account = new Account();
	Scanner scan = new Scanner(System.in);
	
	//계좌, 사용자 생성
	public void genAccount() {
		accounts.add(new Account("Kim", 1234, 50000, new ArrayList<>()));
		accounts.add(new Account("Lee", 2345, 75000, new ArrayList<>()));
		accounts.add(new Account("Park", 3456, 10000, new ArrayList<>()));
	}
	public void genUser() {
		users.add(new User(accounts.get(0), "Kim"));
		users.add(new User(accounts.get(1), "Lee"));
		users.add(new User(accounts.get(2), "Park"));
	}

	public void menu() {
		while (true) {
			System.out.println("=======================");
			System.out.print("사용자를 선택하세요 : \n1. Kim\n2. Lee\n3. Park\n=> ");
			int sel = scan.nextInt();
			curUser = users.get(sel - 1);
			System.out.println("=======================");
			System.out.println(curUser.getName() + "님 안녕하세요");
			System.out.println("잔액 : " + curUser.getAccount().getBalance());
			System.out.print("원하시는 서비스를 선택하세요\n1. 송금\n2. 내역 조회\n3. 로그아웃\n=> ");
			sel = scan.nextInt();
			switch (sel) {
			case 1:
				transfer(curUser);
				break;
			case 2:
				showHistory(curUser.getAccount().getHistory());
				break;
			case 3:
				break;
			}
		}
		
	}
	
	@Override
	public void transfer(User sendUser) {
		int recAcc;
		User recUser;
		Account sendAccount;
		Account recAccount;
		int amount;
		int sel;
		
		sendAccount = sendUser.getAccount();
		System.out.println("=======================");
		System.out.print("송금할 계좌 번호를 입력하세요\n=> ");
		recAcc = scan.nextInt();
		
		for(User user : users) {
			if(!(recAcc == sendAccount.getAccNum()) && recAcc == user.getAccount().getAccNum()) {
				recUser = user;
				recAccount = user.getAccount();
				
				System.out.print("송금할 금액을 입력하세요\n=> ");
				amount = scan.nextInt();
				if(amount <= sendAccount.getBalance()) {
					System.out.print(amount + "원을 " + recUser.getName() + "님에게 보내겠습니까?\n 1.네 2.아니오\n=>");
					sel = scan.nextInt();
					switch(sel) {
					case 1:
						SimpleDateFormat curTime = new SimpleDateFormat("yyyy년 MM월 dd일 HH시 mm분 ");
						String time = curTime.format(new Date());
						
						sendAccount.setBalance(sendAccount.getBalance() - amount);
						sendAccount.getHistory().add(time + "\n송금 : " + recUser.getName() + ", " + amount + "원");
						recAccount.setBalance(recAccount.getBalance() + amount);
						recAccount.getHistory().add(time + "\n입금 : " + sendUser.getName() + ", " + amount + "원");
						
						System.out.println("## 송금되었습니다.##\n잔액 : " + sendAccount.getBalance() + "원 ");
						return;
					case 2:
						System.out.println("## 취소하였습니다.##");
						return;
					}
				} else {
					System.out.println("## 잔액이 부족합니다.##");
					return;
				}
			}
		} 
		System.out.println("## 계좌번호를 잘못 입력했습니다.##");
	}

	@Override
	public void showHistory(ArrayList<String> history) {
		System.out.println("=======================");
		for(int i = 0; i < history.size(); i++) {
			System.out.println(history.get(i));;
		}
	}
	
}
