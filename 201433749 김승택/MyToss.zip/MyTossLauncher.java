package mytoss;

public class MyTossLauncher {
	
	public static void main(String[] args) {
		MyToss mt = new MyToss();
		mt.genAccount();
		mt.genUser();
		mt.menu();
	}

}
