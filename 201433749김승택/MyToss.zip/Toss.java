package mytoss;

import java.util.ArrayList;

public interface Toss {
	void transfer(User curUser);
	void showHistory(ArrayList<String> history);
}
