package mytoss;

import java.util.ArrayList;

public class Account {
	private String owner;
	private int accNum;
	private int balance;
	private ArrayList<String> history;
	public Account() { }
	
	public Account(String owner, int accNum, int balance, ArrayList<String> history) {
		this.owner = owner;
		this.accNum = accNum;
		this.balance = balance;
		this.history = history;
	}
	
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}

	public int getAccNum() {
		return accNum;
	}
	public void setAccNum(int accNum) {
		this.accNum = accNum;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}

	public ArrayList<String> getHistory() {
		return history;
	}

	public void setHistory(ArrayList<String> history) {
		this.history = history;
	}
	
}
