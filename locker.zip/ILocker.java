package locker;

public interface ILocker {
	void setTitle(String title);
	void genUser();
	void genProduct();
	void start();
}
