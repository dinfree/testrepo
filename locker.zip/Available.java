package locker;

public enum Available {사용가능, 사용불가능}
