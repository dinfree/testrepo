package locker;

public class BelDetail extends Belongings {
	public BelDetail(String oname) {
		this.oname = oname;
	}
}
