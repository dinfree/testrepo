package shoppingmall;

public class SportingItem extends Product {

	SportingItem(String productName, int price, int remainingStock) {
		super(productName, price, remainingStock);
	}
}
