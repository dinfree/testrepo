package shoppingmall;

public class Electronic extends Product {

	Electronic(String productName, int price, int remainingStock) {
		super(productName, price, remainingStock);
	}
}
