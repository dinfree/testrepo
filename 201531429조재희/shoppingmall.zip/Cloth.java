package shoppingmall;

public class Cloth extends Product {

	Cloth(String productName, int price, int remainingStock) {
		super(productName, price, remainingStock);
	}
}
